<?php
  $expairy = strtotime('+1 years', $order->created);
  $expairy_date = date('d/m/Y', $expairy);
  $image_url = file_create_url($product->field_giftcard_image['und'][0]['uri']);
?>
 <div class="main-gift-block">
      <div class="main-gift-img">
        <img src="<?php print $image_url; ?>">
      </div>
      <div class="main-gift-content">
        <div class="main-gift-container">
          <form>
            <?php if(!empty($line_item->field_receiever_name)) { ?>
            <div class="form-control-pdf">
             <label> TO: </label><span><?php print $line_item->field_receiever_name['und'][0]['value']; ?></span>
            </div>
            <?php } ?>
            <?php if(!empty($line_item->field_name_of_sender)) { ?>
            <div class="form-control-pdf">
               <label> FROM: </label><span><?php print $line_item->field_name_of_sender['und'][0]['value']; ?></span>
            </div>
            <?php } ?>
            <?php if(!empty($line_item->field_custom_message)) { ?>
            <div class="form-control-pdf">
               <label> MESSAGE: </label><span><?php print $line_item->field_custom_message['und'][0]['value']; ?></span>
            </div>
            <?php } ?>
            <div class="form-control-pdf">
               <label> AMOUNT/TREATMENT: </label><span><?php print commerce_currency_format($line_item->commerce_total['und'][0]['amount'], $line_item->commerce_total['und'][0]['currency_code'], $line_item); ?></span>
            </div>
            <?php
            if($line_item->field_price_type['und'][0]['value'] == 'services') {
            ?>
            <div class="form-control-pdf service-inline">
               <label > SERVICE: </label><span><?php print strip_tags(drupal_render(field_view_field('commerce_line_item', $line_item, 'field_services', array('label' => 'hidden')))); ?></span>
            </div>    
            <?php }
            else if($line_item->field_price_type['und'][0]['value'] == 'packages') {
            ?>
            <div class="form-control-pdf service-inline">
               <label> PACKAGE: </label><span><?php print strip_tags(drupal_render(field_view_field('commerce_line_item', $line_item, 'field_packages', array('label' => 'hidden')))); ?></span>
            </div>                
            <?php
            }
            ?>
           <div class="form-control-pdf">
               <label> DATE OF EXPIRY: </label><span><?php print $expairy_date; ?></span>
            </div>
            
            <div class="form-control-pdf">
               <label> VOUCHER ID NUMBER: </label><span><?php print $order->order_id.'-'.$line_item->line_item_id.'-'.$order->created; ?></span>
            </div>
            
          </form>
        </div>
        <div class="note_text">
          <strong>Please note: </strong> Gift vouchers are non-refundable, cannot be redeemed for cash and will not be replaced if lost. Gift vouchers must be presented at the time of redemption as payment or will be charged for in full. UFS member discount is applied to the purchase of a gift voucher only and is given to the purchaser at the time of purchase. Appointments for gift vouchers are required and are subject to availability. Gift vouchers are not redeemable on private health insurance Vouchers are valid for 12 months from date of purchase.
        </div>
      </div>
  </div>